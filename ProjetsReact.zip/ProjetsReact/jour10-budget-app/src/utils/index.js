export function isNumeric(value) {
    return /^-?\d+$/.test(value);
}