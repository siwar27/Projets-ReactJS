import React from 'react'
import Formulaire from './Formulaire'

function Accueil() {
  return (
    <div>
        <h2>Accueil</h2>
        <Formulaire />
    </div>
  )
}

export default Accueil