import React from 'react'
// si j'ai besoin de charger une fichier .css
// qui est dans le même dossier que le fichier Exemple.jsx 
// il faut OBLIGATOIREMENT mettre un point au début de l'import 
import "./Exemple.css"

// le . est OBLIGATOIRE 

function Exemple() {
  return (
    <div>Exemple</div>
  )
}

export default Exemple