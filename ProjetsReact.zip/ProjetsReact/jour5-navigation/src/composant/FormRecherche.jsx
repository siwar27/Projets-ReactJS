import React from 'react'

function FormRecherche() {
  return (
    <form>
        <input type="text" placeholder='rechercher' />
        <input type="submit" />
    </form>
  )
}

export default FormRecherche