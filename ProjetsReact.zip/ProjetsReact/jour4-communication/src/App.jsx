// imrs
import React, { useState } from 'react';
import Sommaire from './composants/Sommaire';
import Ajax from './composants/Ajax';
import Exo1 from './composants/Exo1';

// ffc
function App() {
  return ( <div>
    <Exo1 />
    <Ajax />
    <Sommaire />
  </div> );
}

export default App;

// rfc
